% Script pour la simulation de la localisation odométrique avec Robotarium

% Sean Wilson
% 07/2019

%% Constantes de l'expérience

% Exécuter la simulation pendant un nombre spécifique d'itérations
iterations = 5000;

%% Configurer l'objet Robotarium

N = 4;
initial_positions = generate_initial_conditions(N, 'Width', 1, 'Height', 1, 'Spacing', 0.3);
r = Robotarium('NumberOfRobots', N, 'ShowFigure', true, 'InitialConditions', initial_positions);

%% Créer le Laplacien souhaité

followers = -completeGL(N-1);
L = zeros(N, N);
L(2:N, 2:N) = followers;
L(2, 2) = L(2, 2) + 1;
L(2, 1) = -1;

dxi = zeros(2, N);
state = 1;

formation_control_gain = 10;
desired_distance = 0.2;

si_to_uni_dyn = create_si_to_uni_dynamics('LinearVelocityGain', 0.8);
uni_barrier_cert = create_uni_barrier_certificate_with_boundary();
leader_controller = create_si_position_controller('XVelocityGain', 0.8, 'YVelocityGain', 0.8, 'VelocityMagnitudeLimit', 0.1);

waypoints = [-1 0.8; -1 -0.8; 1 -0.8; 1 0.8]';
close_enough = 0.03;

CM = ['k','b','r','g'];
marker_size_goal = determine_marker_size(r, 0.20);
font_size = determine_font_size(r, 0.05);
line_width = 5;

for i = 1:length(waypoints)
    goal_caption = sprintf('G%d', i);
    g(i) = plot(waypoints(1,i), waypoints(2,i),'s','MarkerSize',marker_size_goal,'LineWidth',line_width,'Color',CM(i));
    goal_labels{i} = text(waypoints(1,i)-0.05, waypoints(2,i), goal_caption, 'FontSize', font_size, 'FontWeight', 'bold');
end

x = r.get_poses();
[rows, cols] = find(L == 1);

for k = 1:length(rows)/2+1
    lf(k) = line([x(1,rows(k)), x(1,cols(k))],[x(2,rows(k)), x(2,cols(k))], 'LineWidth', line_width, 'Color', 'b'); 
end

for j = 1:N-1    
    follower_caption{j} = sprintf('Follower Robot %d', j);
    follower_labels{j} = text(500, 500, follower_caption{j}, 'FontSize', font_size, 'FontWeight', 'bold');
end

leader_label = text(500, 500, 'Leader Robot', 'FontSize', font_size, 'FontWeight', 'bold', 'Color', 'r');

% Ajout de la gestion des tracés pour chaque robot
robot_plots = cell(1, N);

for i = 1:N
    robot_plots{i} = plot(0, 0, 'LineWidth', 2, 'DisplayName', ['Robot ' num2str(i)]);
end

%% Constantes de la localisation odométrique

% Paramètres du bruit du modèle odométrique
odometric_noise_mean = 0;
odometric_noise_std = 0.01;

% Initialiser les estimations de pose odométrique
odometric_pose = zeros(3, N);

% Initialiser les matrices pour stocker les vraies et estimées poses pour le tracé
true_poses = zeros(3, N, iterations);
estimated_poses = zeros(3, N, iterations);

%% Configuration des modèles odométriques

% Paramètres du modèle odométrique
wheel_radius = 0.05; % rayon de la roue (en mètres)
robot_radius = 0.1; % rayon du robot (en mètres)

% Initialiser les estimations de pose odométrique pour le modèle odométrique basé sur les roues
odometric_pose_wheels = zeros(3, N);

% Initialiser les matrices pour stocker les vraies et estimées poses pour le tracé
true_poses_wheels = zeros(3, N, iterations);
estimated_poses_wheels = zeros(3, N, iterations);

%% Configuration de l'enregistrement des données pour le modèle odométrique des roues

robot_distance_wheels = zeros(5, iterations);
goal_distance_wheels = [];
start_time_wheels = tic;

r.step();

for t = 1:iterations
    % x = r.get_poses();
    
    % ... (le reste du code reste inchangé)
    for i = 2:N
        dxi(:, i) = [0 ; 0];
        
        neighbors = topological_neighbors(L, i);
        
        for j = neighbors
            dxi(:, i) = dxi(:, i) + ...
                formation_control_gain*(norm(x(1:2, j) - x(1:2, i))^2 -  desired_distance^2)*(x(1:2, j) - x(1:2, i));
        end
    end
    
    waypoint = waypoints(:, state);
    
    switch state        
        case 1
            dxi(:, 1) = leader_controller(x(1:2, 1), waypoint);
            if(norm(x(1:2, 1) - waypoint) < close_enough)
                state = 2;
            end
        case 2
            dxi(:, 1) = leader_controller(x(1:2, 1), waypoint);
            if(norm(x(1:2, 1) - waypoint) < close_enough)
                state = 3;
            end
        case 3
            dxi(:, 1) = leader_controller(x(1:2, 1), waypoint);
            if(norm(x(1:2, 1) - waypoint) < close_enough)
                state = 4;
            end
        case 4
            dxi(:, 1) = leader_controller(x(1:2, 1), waypoint);
            if(norm(x(1:2, 1) - waypoint) < close_enough)
                state = 1;
            end
    end
    
    norms = arrayfun(@(x) norm(dxi(:, x)), 1:N);
    threshold = 3/4*r.max_linear_velocity;
    to_thresh = norms > threshold;
    dxi(:, to_thresh) = threshold*dxi(:, to_thresh)./norms(to_thresh);
    
    dxu = si_to_uni_dyn(dxi, x);
    dxu = uni_barrier_cert(dxu, x);
    
    r.set_velocities(1:N, dxu);
    
    for q = 1:N-1
        follower_labels{q}.Position = x(1:2, q+1) + [-0.15;0.15];    
    end
    
    for m = 1:length(rows)/2+1
        lf(m).XData = [x(1,rows(m)), x(1,cols(m))];
        lf(m).YData = [x(2,rows(m)), x(2,cols(m))];
    end
    
    leader_label.Position = x(1:2, 1) + [-0.15;0.15];
    %ll.XData = [x(1,1), x(1,2)];
    %ll.YData = [x(2,1), x(2,2)];
    
    marker_size_goal = num2cell(ones(1,length(waypoints))*determine_marker_size(r, 0.20));
    [g.MarkerSize] = marker_size_goal{:};
    font_size = determine_font_size(r, 0.05);
    leader_label.FontSize = font_size;
    
    for n = 1:N
        follower_labels{n}.FontSize = font_size;
        goal_labels{n}.FontSize = font_size;
    end
    
    % Get odometric poses with noise for the wheel model
    for i = 1:N
        odometric_pose_wheels(:, i) = update_pose_wheels(odometric_pose_wheels(:, i), dxu(:, i), wheel_radius);
        true_poses_wheels(:, i, t) = x(:, i);
        estimated_poses_wheels(:, i, t) = odometric_pose_wheels(:, i);
    end
    
    robot_distance_wheels(1, t) = norm([x(1:2,1) - x(1:2,2)], 2);
    robot_distance_wheels(5, t) = toc(start_time_wheels);
    
    for b = 1:length(rows)/2+1
        robot_distance_wheels(b+1, t) = norm([x(1:2,rows(b)) - x(1:2,cols(b))], 2);   
    end
    
    if(norm(x(1:2, 1) - waypoint) < close_enough)
        goal_distance_wheels = [goal_distance_wheels [norm(x(1:2, 1) - waypoint);toc(start_time_wheels)]];
    end
    
    r.step();
end

save('DistanceData_Wheels.mat', 'robot_distance_wheels');
save('GoalData_Wheels.mat', 'goal_distance_wheels');

r.debug();

plot_poses(true_poses, estimated_poses, true_poses_wheels, estimated_poses_wheels, iterations);

%% Fonction pour mettre à jour la pose basée sur le modèle odométrique des roues

function updated_pose = update_pose_wheels(previous_pose, velocity, wheel_radius)
    dt = 0.033;
    linear_velocity = velocity(1);
    angular_velocity = velocity(2);
    
    % Modèle odométrique basé sur les roues
    updated_pose = previous_pose + [
        linear_velocity * cos(previous_pose(3));
        linear_velocity * sin(previous_pose(3));
        (linear_velocity / wheel_radius) * tan(angular_velocity)
    ] * dt;
end

%% Fonction pour gérer les marker size
function marker_size = determine_marker_size(robotarium_instance, marker_size_meters)
    curunits = get(robotarium_instance.figure_handle, 'Units');
    set(robotarium_instance.figure_handle, 'Units', 'Points');
    cursize = get(robotarium_instance.figure_handle, 'Position');
    set(robotarium_instance.figure_handle, 'Units', curunits);
    marker_ratio = (marker_size_meters)/(robotarium_instance.boundaries(2) - robotarium_instance.boundaries(1));
    marker_size = cursize(3) * marker_ratio;
end

function font_size = determine_font_size(robotarium_instance, font_height_meters)
    curunits = get(robotarium_instance.figure_handle, 'Units');
    set(robotarium_instance.figure_handle, 'Units', 'Points');
    cursize = get(robotarium_instance.figure_handle, 'Position');
    set(robotarium_instance.figure_handle, 'Units', curunits);
    font_ratio = (font_height_meters)/(robotarium_instance.boundaries(4) - robotarium_instance.boundaries(3));
    font_size = cursize(4) * font_ratio;
end



function plot_poses(true_poses, estimated_poses, true_poses_wheels, estimated_poses_wheels, iterations)
    figure;

    % Existing Model Plots
    for i = 1:size(true_poses, 2)
        subplot(2, 4, i);
        plot(1:iterations, squeeze(true_poses(1, i, :)), 'b-', 'LineWidth', 2, 'DisplayName', 'True X');
        hold on;
        plot(1:iterations, squeeze(estimated_poses(1, i, :)), 'r--', 'LineWidth', 2, 'DisplayName', 'Estimated X');
        title(['Robot ' num2str(i) ' - X Position (Existing Model)']);
        legend('show');
    end

    % Wheel Model Plots
    for i = 1:size(true_poses_wheels, 2)
        subplot(2, 4, i + 4);
        plot(1:iterations, squeeze(true_poses_wheels(1, i, :)), 'b-', 'LineWidth', 2, 'DisplayName', 'True X (Wheels)');
        hold on;
        plot(1:iterations, squeeze(estimated_poses_wheels(1, i, :)), 'r--', 'LineWidth', 2, 'DisplayName', 'Estimated X (Wheels)');
        title(['Robot ' num2str(i) ' - X Position (Wheel Model)']);
        legend('show');
    end

    % Overall Title
    sgtitle('True vs Estimated Poses');
end
