clear all

load('dqg.mat')
load('dqd.mat')
load('Xtruth.mat')
load('Ytruth.mat')


l1=[0.5 1.4];
l2=[2 0.6];
l3=[3 1];
l=[l1; l2 ;l3]; %les coordon�es des 3 amers

r=(70/2)*10^-3; %rayon des roues droites et gauches
e=230*10^-3; %voie (distance entre les 2 roues)

%pose initiale
odometer(1,1)=0;
odometer(2,1)=0.5;
odometer(3,1)=0;


Qu=[0.5*10^-4 0; 0 0.5*10^-4]; %covariance associ�e aux bruits du vecteur d'entr�e
Q=[0.6*10^-5 0 0;0 0.4*10^-5 0;0 0 10^-5]; %covariance du bruit de mod�le 
podo=[1 0 0 ; 0 1 0 ;0 0 0.5]; %valeur initiale de la matrice de covariance P

R=10^-5; %covariance du bruit de mesure (� adapter la valeur)

